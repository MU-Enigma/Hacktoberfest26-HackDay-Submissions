// Shared attendance maths. Same file is used by the extension popup and the React app.
// Definitions: A = classes attended, H = classes held (total - not-entered), t = target as a fraction (0.75)
export const DEFAULT_TARGET = 75;
const EPS = 1e-9;

export function analyze(s, target = DEFAULT_TARGET) {
  const A = s.present, H = s.held, t = target / 100;
  const ok = A >= t * H - EPS;                       // at or above target
  const pct = H > 0 ? (A / H) * 100 : 100;

  // Max classes you can still MISS and stay >= target:  A/(H+x) >= t  ->  x <= A/t - H
  const canMiss = t >= 1 ? 0 : Math.max(0, Math.floor(A / t - H + EPS));

  // Consecutive classes you must ATTEND to reach target:  (A+y)/(H+y) >= t  ->  y >= (tH - A)/(1 - t)
  const need = ok ? 0 : t >= 1 ? Infinity : Math.ceil((t * H - A) / (1 - t) - EPS);

  const status = !ok ? "danger" : canMiss === 0 ? "edge" : "safe";
  return { ...s, target, pct, canMiss, need, status };
}

// Projected % after attending `attend` more and missing `miss` more classes
export function project(s, attend = 0, miss = 0) {
  const H = s.held + attend + miss;
  return H > 0 ? ((s.present + attend) / H) * 100 : 100;
}

// Overall % across all subjects (sum present / sum held)
export function overall(subjects) {
  const A = subjects.reduce((n, s) => n + s.present, 0);
  const H = subjects.reduce((n, s) => n + s.held, 0);
  return { present: A, held: H, pct: H > 0 ? (A / H) * 100 : 100 };
}

const norm = (x) => String(x || "").toLowerCase().replace(/[^a-z0-9]/g, "");
function findSubject(map, name) {
  const n = norm(name);
  if (map.has(n)) return map.get(n);
  for (const [k, v] of map) if (k && n && (k.includes(n) || n.includes(k))) return v;
  return null;
}

// Walk through a day's classes in order. "skip" = you can miss it and still stay >= target
// (assuming you attend whatever the plan says to attend). "attend" = missing it would drop you below target.
export function planClasses(classes, subjects, targetFor = () => DEFAULT_TARGET) {
  const state = new Map(subjects.map((s) => [norm(s.name), { A: s.present, H: s.held, s }]));
  return classes.map((c) => {
    const st = findSubject(state, c.name);
    if (!st) return { ...c, action: "unknown" };
    const t = targetFor(st.s) / 100;
    if (st.A >= t * (st.H + 1) - EPS) {            // A/(H+1) >= t
      st.H += 1;
      return { ...c, action: "skip", pct: (st.A / st.H) * 100 };
    }
    st.A += 1; st.H += 1;
    return { ...c, action: "attend", pct: (st.A / st.H) * 100 };
  });
}
