// Demo data so the app works without the extension (use for the hackathon demo)
export const MOCK = {
  subjects: [
    { code: "MA101", name: "Calculus And ODE", total: 30, present: 24, notEntered: 2, held: 28 },
    { code: "CS101", name: "Introduction to Computing", total: 36, present: 22, notEntered: 0, held: 36 },
    { code: "EE101", name: "Introduction to Electrical Engineering", total: 34, present: 31, notEntered: 1, held: 33 },
    { code: "CH101", name: "Quantum Chemistry And Spectroscopy", total: 24, present: 18, notEntered: 0, held: 24 },
    { code: "EN101", name: "English", total: 20, present: 19, notEntered: 0, held: 20 },
  ],
  today: [
    { time: "09:25 AM-10:20 AM", name: "Introduction to Electrical Engineering" },
    { time: "10:35 AM-11:30 AM", name: "Introduction to Computing" },
    { time: "11:35 AM-12:30 PM", name: "Introduction to Electrical Engineering" },
    { time: "12:35 PM-01:30 PM", name: "Quantum Chemistry And Spectroscopy" },
    { time: "02:35 PM-03:30 PM", name: "Calculus And ODE" },
    { time: "03:35 PM-04:30 PM", name: "English" },
  ],
};
