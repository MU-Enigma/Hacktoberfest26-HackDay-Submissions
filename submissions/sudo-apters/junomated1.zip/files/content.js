// Runs on Juno pages. Reads tables from the page you're already logged into and saves them locally.
const clean = (c) => c.innerText.trim().replace(/\s+/g, " ");
const num = (v) => { const n = parseInt(String(v ?? "").replace(/[^\d-]/g, ""), 10); return Number.isNaN(n) ? null : n; };

function allDocs() {
  const docs = [document];
  document.querySelectorAll("iframe,frame").forEach((f) => { try { if (f.contentDocument) docs.push(f.contentDocument); } catch {} });
  return docs;
}
const tableRows = (t) => [...t.rows].map((r) => [...r.cells].map(clean));

function parseAttendance() {
  let best = [];
  for (const d of allDocs()) {
    for (const t of d.querySelectorAll("table")) {
      const rows = tableRows(t);
      const hi = rows.findIndex((r) => r.some((c) => /total|conducted|held/i.test(c)) && r.some((c) => /present|attended/i.test(c)));
      if (hi < 0) continue;

      const h = rows[hi].map((x) => x.toLowerCase());
      const f = (re) => h.findIndex((x) => re.test(x));
      const idx = {
        code: f(/course\s*code|^code$/),
        name: f(/course\s*name|name|title|subject/),
        // Strict: "Total Count", never "Total Sessions"
        total: f(/^total\s*count$/) >= 0 ? f(/^total\s*count$/) : f(/conducted|held/),
        present: f(/^present\s*count$/) >= 0 ? f(/^present\s*count$/) : f(/present|attended/),
      };
      if (idx.total < 0 || idx.present < 0) continue;
      if (idx.name < 0) idx.name = 1;

      const out = [];
      for (const r of rows.slice(hi + 1)) {
        const total = num(r[idx.total]), present = num(r[idx.present]);
        if (total == null || present == null || present > total) continue;
        out.push({
          code: idx.code >= 0 ? r[idx.code] || "" : "",
          name: r[idx.name] || r[idx.code] || "Subject",
          total,
          present,
          notEntered: 0,
          held: total,
        });
      }
      if (out.length > best.length) best = out;
    }
  }
  return best;
}

const TIME = /^\d{1,2}:\d{2}\s*[AP]M\s*-\s*\d{1,2}:\d{2}\s*[AP]M$/i;
const startMin = (s) => { const m = s.match(/(\d{1,2}):(\d{2})\s*([AP])M/i); return (m[1] % 12 + (m[3].toUpperCase() === "P" ? 12 : 0)) * 60 + +m[2]; };

function parseTimetable() {
  for (const d of allDocs()) for (const t of d.querySelectorAll("table")) {
    const rows = tableRows(t).filter((r) => r.length);
    for (let i = 0; i < rows.length - 1; i++) {
      if (rows[i].every((c) => TIME.test(c)) && rows[i + 1].length === rows[i].length) {
        return rows[i].map((time, k) => ({ time, name: rows[i + 1][k] })).sort((a, b) => startMin(a.time) - startMin(b.time));
      }
    }
  }
  return [];
}

function scan() {
  const subjects = parseAttendance();
  const today = parseTimetable();
  const save = {};
  if (subjects.length) Object.assign(save, { subjects, subjectsAt: Date.now() });
  if (today.length) Object.assign(save, { today, todayAt: Date.now() });
  if (Object.keys(save).length) chrome.storage.local.set(save);
  return { subjects: subjects.length, today: today.length };
}

setTimeout(scan, 1500);
chrome.runtime.onMessage.addListener((msg, _s, send) => { if (msg.action === "scan") send(scan()); });