import { analyze, overall, planClasses, DEFAULT_TARGET } from "./attendance.js";
const APP_URL = "http://localhost:5173/"; // your React app
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
let store = {};

async function load() { store = await chrome.storage.local.get(["subjects", "today"]); render(); }

function render() {
  const { subjects, today } = store;
  if (!subjects?.length) { $("out").innerHTML = "<p>No attendance yet. Open Juno's attendance page, then press Rescan.</p>"; return; }
  const rows = subjects.map((s) => analyze(s, DEFAULT_TARGET)).sort((a, b) => b.need - a.need || a.canMiss - b.canMiss);
  const o = overall(subjects);
  let html = `<div class="sum"><b>Overall ${o.pct.toFixed(1)}%</b> (${o.present}/${o.held})</div>`;
  for (const d of rows) {
    const line = d.status === "danger" ? `Attend next <b>${d.need}</b> in a row to reach ${d.target}%`
      : d.canMiss === 0 ? "Don't miss any class" : `Can miss <b>${d.canMiss}</b> more`;
    html += `<div class="card ${d.status}"><span class="pct">${d.pct.toFixed(1)}%</span><b>${esc(d.name)}</b>
      <div class="sm">${d.present}/${d.held} held · ${line}</div></div>`;
  }
  if (today?.length) {
    html += "<h3>Today</h3>";
    for (const c of planClasses(today, subjects, () => DEFAULT_TARGET))
      html += `<div class="sm">${esc(c.time)} · ${esc(c.name)} → <b>${c.action === "skip" ? "can skip" : c.action === "attend" ? "attend" : "?"}</b></div>`;
  }
  $("out").innerHTML = html;
}

$("scan").onclick = async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.tabs.sendMessage(tab.id, { action: "scan" }, async () => {
    if (chrome.runtime.lastError) { $("out").innerHTML = "<p style='color:#c8372d'>Open a Juno page first, then reload it.</p>"; return; }
    await load();
  });
};
$("open").onclick = () => {
  if (!store.subjects?.length) return;
  const json = JSON.stringify({ subjects: store.subjects, today: store.today || [] });
  window.open(`${APP_URL}#data=${btoa(unescape(encodeURIComponent(json)))}`, "_blank");
};
load();
