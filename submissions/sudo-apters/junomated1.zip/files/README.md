# JunoMate setup

## 1. Chrome extension
1. chrome://extensions -> Developer mode -> Load unpacked -> pick the `extension` folder
2. Log in to Juno, open the attendance page (studentCourses.htm?shwA='00A'), wait 2 seconds
3. Click the JunoMate icon -> Rescan this page. Visit home.htm once to capture today's timetable.

## 2. React app
npm create vite@latest junomate-app -- --template react
cd junomate-app && npm install
Copy app/src/* into junomate-app/src/ (overwrite App.jsx, App.css), keep main.jsx importing App
npm run dev   (must run on http://localhost:5173, or change APP_URL in extension/popup.js)

Extension popup -> "Open in app" sends your data via the URL hash. Nothing leaves your machine.
