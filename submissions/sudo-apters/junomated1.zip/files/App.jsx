import { useEffect, useMemo, useState } from "react";
import { analyze, overall, project, planClasses, DEFAULT_TARGET } from "./attendance.js";
import { MOCK } from "./mock.js";
import "./App.css";

// ---- Data adapter: swap the source, nothing else changes ----
function loadFromHash() {
  const m = location.hash.match(/data=(.+)/);
  if (!m) return null;
  try { return JSON.parse(decodeURIComponent(escape(atob(m[1])))); } catch { return null; }
}
const LS = "junomate:v1";
const readLS = () => { try { return JSON.parse(localStorage.getItem(LS)) || {}; } catch { return {}; } };

export default function App() {
  const saved = useMemo(readLS, []);
  const [data, setData] = useState(() => loadFromHash() || saved.data || null);
  const [globalTarget, setGlobalTarget] = useState(saved.globalTarget ?? DEFAULT_TARGET);
  const [targets, setTargets] = useState(saved.targets || {});       // per-subject overrides
  const [paste, setPaste] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => {
    try { localStorage.setItem(LS, JSON.stringify({ data, globalTarget, targets })); } catch {}
  }, [data, globalTarget, targets]);
  useEffect(() => { if (location.hash) history.replaceState(null, "", location.pathname); }, []);

  const key = (s) => s.code || s.name;
  const targetFor = (s) => targets[key(s)] ?? globalTarget;

  const rows = useMemo(() => {
    if (!data) return [];
    return data.subjects.map((s) => analyze(s, targetFor(s)))
      .sort((a, b) => b.need - a.need || a.canMiss - b.canMiss);
  }, [data, globalTarget, targets]);

  const total = data ? overall(data.subjects) : null;
  const plan = data?.today?.length ? planClasses(data.today, data.subjects, targetFor) : [];

  function importPaste() {
    try {
      const j = JSON.parse(paste);
      if (!j.subjects?.length) throw new Error();
      setData({ subjects: j.subjects, today: j.today || [] }); setErr(""); setPaste("");
    } catch { setErr("That isn't valid JunoMate JSON. Use the extension's Open in app button, or load the demo data."); }
  }

  if (!data) return (
    <main className="wrap">
      <h1>JunoMate</h1>
      <p className="lede">See which classes you can skip and which you can't, subject by subject.</p>
      <section className="panel">
        <h2>Get your attendance in</h2>
        <button className="primary" onClick={() => setData(MOCK)}>Load demo data</button>
        <p className="muted">Or open Juno, click the JunoMate extension, then Open in app. You can also paste the JSON:</p>
        <textarea value={paste} onChange={(e) => setPaste(e.target.value)} rows={4} placeholder='{"subjects":[{"name":"...","present":20,"held":25}]}' />
        <button onClick={importPaste}>Import JSON</button>
        {err && <p className="error">{err}</p>}
      </section>
    </main>
  );

  return (
    <main className="wrap">
      <header className="top">
        <div>
          <h1>JunoMate</h1>
          <p className="muted">Overall {total.pct.toFixed(1)}% · {total.present} of {total.held} classes</p>
        </div>
        <label className="target">Default target
          <input type="number" min="1" max="99" value={globalTarget}
            onChange={(e) => setGlobalTarget(Math.min(99, Math.max(1, +e.target.value || DEFAULT_TARGET)))} />%
        </label>
        <button onClick={() => setData(null)}>Change data</button>
      </header>

      {plan.length > 0 && (
        <section className="panel">
          <h2>Today's classes</h2>
          <ul className="plan">
            {plan.map((c, i) => (
              <li key={i} className={c.action}>
                <span className="time">{c.time}</span>
                <span className="cname">{c.name}</span>
                <span className="act">{c.action === "skip" ? "Can skip" : c.action === "attend" ? "Attend" : "Not matched"}</span>
              </li>
            ))}
          </ul>
          <p className="muted">Each class is judged after the ones before it, assuming you follow the plan.</p>
        </section>
      )}

      <section className="grid">
        {rows.map((r) => <SubjectCard key={key(r)} r={r}
          onTarget={(v) => setTargets((t) => ({ ...t, [key(r)]: v }))} />)}
      </section>
    </main>
  );
}

function SubjectCard({ r, onTarget }) {
  const [att, setAtt] = useState(0);
  const [miss, setMiss] = useState(0);
  const after = project(r, att, miss);
  const msg = r.status === "danger" ? `Attend the next ${r.need} classes in a row to reach ${r.target}%`
    : r.canMiss === 0 ? "You can't miss any more classes" : `You can miss ${r.canMiss} more and stay at ${r.target}%`;
  return (
    <article className={`card ${r.status}`}>
      <div className="head">
        <h3>{r.name}</h3>
        <span className="pct">{r.pct.toFixed(1)}%</span>
      </div>
      <div className="bar" aria-label={`${r.pct.toFixed(1)} percent, target ${r.target}`}>
        <i style={{ width: `${Math.min(100, r.pct)}%` }} />
        <b style={{ left: `${r.target}%` }} />
      </div>
      <p className="verdict">{msg}</p>
      <p className="muted">{r.present} attended of {r.held} held{r.notEntered ? ` (${r.notEntered} not entered yet)` : ""}</p>
      <div className="whatif">
        <label>Attend <input type="number" min="0" value={att} onChange={(e) => setAtt(Math.max(0, +e.target.value || 0))} /></label>
        <label>Miss <input type="number" min="0" value={miss} onChange={(e) => setMiss(Math.max(0, +e.target.value || 0))} /></label>
        <span className={after >= r.target ? "ok" : "bad"}>→ {after.toFixed(1)}%</span>
      </div>
      <label className="muted tgt">Target for this subject
        <input type="number" min="1" max="99" value={r.target} onChange={(e) => onTarget(Math.min(99, Math.max(1, +e.target.value || DEFAULT_TARGET)))} />%
      </label>
    </article>
  );
}
